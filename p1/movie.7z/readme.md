# Movie station

## content 

It is a movie information website which grabs info from maoyan api

## dependency

test successfully on python3 