# Movie station

## content 

It is a movie information website which grabs info from maoyan api

## dependency

test successfully on python3

## Usage

run

```
python3 entertainment_center.py
``` 